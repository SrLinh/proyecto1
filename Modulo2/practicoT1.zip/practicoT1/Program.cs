﻿using System;
using System.ComponentModel.DataAnnotations.Schema;
class Matriz
{
    public int fila;
    public int columna;
    public int[,] matriz;

    public void Parametros()
    {
        Console.WriteLine("Ingresa el numero de columnas");
        columna = Convert.ToInt32(Console.ReadLine());

        Console.WriteLine("Ingresa el numero de filas");
        fila = Convert.ToInt32(Console.ReadLine());

        matriz = new int[fila, columna];

        for (int i = 0; i < fila; i++)
        {
            for (int j = 0; j < columna; j++)
            {
                Console.WriteLine($"Ingresa valor para [{i},{j}]");
                matriz[i, j] = Convert.ToInt32(Console.ReadLine());
            }
        }
    }

    public void SumarFilas()
    {
        for (int i = 0; i < fila; i++)
        {
            int suma = 0;

            for (int j = 0; j < columna; j++)
            {
                suma += matriz[i, j];
            }

            Console.WriteLine($"Suma de la fila {i}: {suma}");
        }
    }

    public void Transposicion()
    {
        int[,] matrizTranspuesta = new int[columna, fila];

        for (int i = 0; i < fila; i++)
        {
            for (int j = 0; j < columna; j++)
            {
                matrizTranspuesta[j , i] = matriz[i , j];
            }
        }

        Console.WriteLine("Matriz Normal");
        for (int i = 0; i < fila; i++)
        {
            for (int j = 0; j < columna; j++)
            {
                Console.Write($"{matriz[i, j]} ");
            }
            Console.WriteLine();
        }
        Console.WriteLine("Matriz transpuesta");
        for (int i = 0; i < fila; i++)
        {
            for (int j = 0; j < columna; j++)
            {
                Console.Write($"{matrizTranspuesta[i , j]} ");
            }
            Console.WriteLine();
        }


    }
}
class Program
{
    static void Main(string[] args)
    {
        Matriz m = new Matriz();
        m.Parametros();
        m.SumarFilas();
        m. Transposicion();
    }
}
