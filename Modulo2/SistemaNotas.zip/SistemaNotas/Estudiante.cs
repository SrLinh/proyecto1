namespace SistemaNotas;

public class Estudiante
{
    public string Codigo { get; private set; }
    public string Nombre { get; private set; }
    public double Nota1 { get; private set; }
    public double Nota2 { get; private set; }
    public double Nota3 { get; private set; }

    public Estudiante(string codigo, string nombre, double nota1, double nota2, double nota3)
    {
        if (string.IsNullOrWhiteSpace(codigo))
        {
            throw new NotaException("El código del estudiante no puede estar vacío.");
        }

        if (string.IsNullOrWhiteSpace(nombre))
        {
            throw new NotaException("El nombre del estudiante no puede estar vacío.");
        }

        ValidarNota(nota1);
        ValidarNota(nota2);
        ValidarNota(nota3);

        Codigo = codigo.Trim().ToUpper();
        Nombre = nombre.Trim();
        Nota1 = nota1;
        Nota2 = nota2;
        Nota3 = nota3;
    }

    public double CalcularPromedio()
    {
        return (Nota1 + Nota2 + Nota3) / 3;
    }

    public bool EstaAprobado()
    {
        return CalcularPromedio() >= 6.0;
    }

    public string ObtenerEstado()
    {
        if (EstaAprobado())
        {
            return "APROBADO";
        }

        return "REPROBADO";
    }

    public void ModificarNotas(double nuevaNota1, double nuevaNota2, double nuevaNota3)
    {
        ValidarNota(nuevaNota1);
        ValidarNota(nuevaNota2);
        ValidarNota(nuevaNota3);

        Nota1 = nuevaNota1;
        Nota2 = nuevaNota2;
        Nota3 = nuevaNota3;
    }

    private void ValidarNota(double nota)
    {
        if (nota < 0 || nota > 10)
        {
            throw new NotaException("La nota debe estar entre 0 y 10.");
        }
    }

    public string ConvertirAFormatoArchivo()
    {
        return $"{Codigo}|{Nombre}|{Nota1}|{Nota2}|{Nota3}";
    }
}