﻿using System;
namespace  ejercicio;
class program {
    static void Main (String[] args)
    {
        string alumno= "Wendy";
        int edad= 26;
        double nota= 9.50;
        bool estaAprobado= true;
        char seccion= 'A';
        System.Console.WriteLine(" Alumno:" + alumno + " Edad:" + edad +" Nota:" + nota + " Aprobado:" + estaAprobado + " Seccion:" + seccion);

    }
    



    
}